/* Service worker: guarda la app en la Cache API para abrirla sin conexión.
   Si cambias algún archivo, sube el número de VERSION para que se actualice. */
const VERSION = "v2";
const CACHE_APP = `cbtis260-app-${VERSION}`;
const ARCHIVOS = [
  "./",
  "./modelopwa.html",
  "./estilos.css",
  "./app.js",
  "./manifest.json",
  "./icon.svg",
  "./imagenes/fondo.gif",
  "./imagenes/logocbtis.jpg"
];

self.addEventListener("install", (evento) => {
  evento.waitUntil(
    caches.open(CACHE_APP)
      // allSettled: si falta alguna imagen opcional, la instalación no falla.
      .then((cache) => Promise.allSettled(ARCHIVOS.map((a) => cache.add(a))))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (evento) => {
  evento.waitUntil(
    caches.keys()
      // Borra solo versiones viejas de la app; conserva "cbtis260-modelo" (modelo entrenado).
      .then((nombres) => Promise.all(nombres.filter((n) => n.startsWith("cbtis260-app-") && n !== CACHE_APP).map((n) => caches.delete(n))))
      .then(() => self.clients.claim())
  );
});

// Estrategia "caché primero y actualiza en segundo plano".
self.addEventListener("fetch", (evento) => {
  const peticion = evento.request;
  if (peticion.method !== "GET" || new URL(peticion.url).origin !== self.location.origin) return;
  evento.respondWith(
    caches.open(CACHE_APP).then(async (cache) => {
      const guardada = await cache.match(peticion, { ignoreSearch: true });
      const red = fetch(peticion)
        .then((resp) => { if (resp && resp.ok) cache.put(peticion, resp.clone()); return resp; })
        .catch(() => null);
      if (guardada) { evento.waitUntil(red); return guardada; }
      const resp = await red;
      if (resp) return resp;
      if (peticion.mode === "navigate") return cache.match("./modelopwa.html");
      return new Response("Sin conexión", { status: 503, statusText: "Sin conexión" });
    })
  );
});
