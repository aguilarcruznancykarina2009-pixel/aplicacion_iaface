/* Clasificador educativo 100 % local: sin bibliotecas externas ni descargas.
   1) Se extraen características visuales (color, bordes, forma) con canvas.
   2) Una red neuronal pequeña (escrita en JS puro) aprende dos categorías.
   Cachés: memoria (características por archivo) + Cache API (modelo entrenado y archivos de la app). */
(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const categorias = {
    A: { archivos: [], input: $("fotosA"), vista: $("vistaA"), contador: $("contadorA"), nombre: $("nombreA"), limpiar: $("limpiarA") },
    B: { archivos: [], input: $("fotosB"), vista: $("vistaB"), contador: $("contadorB"), nombre: $("nombreB"), limpiar: $("limpiarB") }
  };
  let clasificador = null;
  let camara = null;
  let fotoSeleccionada = null;
  let urlFoto = null;
  let entrenamientoEnCurso = false;
  const UMBRAL_CONFIANZA = 0.65;
  const MAX_IMAGENES = 8;
  const MIN_IMAGENES = 5;
  const EPOCAS = 60;

  /* ============ Motor de IA local ============ */
  const TAM = 48; // las imágenes se reducen a 48×48 para analizarlas
  const lienzo = document.createElement("canvas");
  lienzo.width = lienzo.height = TAM;
  const ctx = lienzo.getContext("2d", { willReadFrequently: true });

  // Recorta el centro en cuadrado, lo reduce y devuelve los píxeles (con volteo y brillo opcionales).
  function leerPixeles(img, volteo, brillo) {
    const w = img.naturalWidth || img.videoWidth || img.width;
    const h = img.naturalHeight || img.videoHeight || img.height;
    const lado = Math.min(w, h);
    ctx.save();
    ctx.clearRect(0, 0, TAM, TAM);
    if (volteo) { ctx.translate(TAM, 0); ctx.scale(-1, 1); }
    ctx.drawImage(img, (w - lado) / 2, (h - lado) / 2, lado, lado, 0, 0, TAM, TAM);
    ctx.restore();
    const origen = ctx.getImageData(0, 0, TAM, TAM).data;
    if (brillo === 1) return origen;
    const salida = new Uint8ClampedArray(origen.length);
    for (let i = 0; i < origen.length; i += 4) {
      salida[i] = origen[i] * brillo; salida[i + 1] = origen[i + 1] * brillo;
      salida[i + 2] = origen[i + 2] * brillo; salida[i + 3] = 255;
    }
    return salida;
  }

  // Vector de 143 números: color por zonas, histogramas de matiz/saturación/brillo y orientación de bordes.
  function extraerCaracteristicas(d) {
    const N = TAM * TAM;
    const gris = new Float32Array(N);
    const rejilla = new Float32Array(48);
    const matiz = new Float32Array(12), sat = new Float32Array(4), val = new Float32Array(4);
    let suma = 0, suma2 = 0;
    for (let y = 0; y < TAM; y++) {
      for (let x = 0; x < TAM; x++) {
        const p = y * TAM + x, i = p * 4;
        const r = d[i] / 255, g = d[i + 1] / 255, b = d[i + 2] / 255;
        const max = Math.max(r, g, b), min = Math.min(r, g, b), delta = max - min;
        const l = 0.299 * r + 0.587 * g + 0.114 * b;
        gris[p] = l; suma += l; suma2 += l * l;
        const c = Math.floor(y / 12) * 4 + Math.floor(x / 12);
        rejilla[c * 3] += r; rejilla[c * 3 + 1] += g; rejilla[c * 3 + 2] += b;
        const s = max === 0 ? 0 : delta / max;
        let h = 0;
        if (delta > 0) {
          if (max === r) h = ((g - b) / delta + 6) % 6;
          else if (max === g) h = (b - r) / delta + 2;
          else h = (r - g) / delta + 4;
          h /= 6;
        }
        if (s > 0.15 && max > 0.15) matiz[Math.min(11, Math.floor(h * 12))] += s * max;
        sat[Math.min(3, Math.floor(s * 4))]++;
        val[Math.min(3, Math.floor(max * 4))]++;
      }
    }
    for (let i = 0; i < 48; i++) rejilla[i] /= 144;
    for (let i = 0; i < 12; i++) matiz[i] /= N;
    for (let i = 0; i < 4; i++) { sat[i] /= N; val[i] /= N; }

    const bordes = new Float32Array(72);
    let fuerza = 0;
    for (let y = 1; y < TAM - 1; y++) {
      for (let x = 1; x < TAM - 1; x++) {
        const p = y * TAM + x;
        const gx = gris[p + 1] - gris[p - 1], gy = gris[p + TAM] - gris[p - TAM];
        const mag = Math.sqrt(gx * gx + gy * gy);
        if (mag < 1e-4) continue;
        let ang = Math.atan2(gy, gx);
        if (ang < 0) ang += Math.PI;
        const bin = Math.min(7, Math.floor((ang / Math.PI) * 8));
        const celda = Math.floor((y * 3) / TAM) * 3 + Math.floor((x * 3) / TAM);
        bordes[celda * 8 + bin] += mag;
        fuerza += mag;
      }
    }
    for (let i = 0; i < 72; i++) bordes[i] /= N / 9;
    const media = suma / N;
    const desv = Math.sqrt(Math.max(0, suma2 / N - media * media));
    return [...rejilla, ...matiz, ...sat, ...val, ...bordes, media, desv, fuerza / N];
  }

  // Caché en memoria: cada imagen se analiza una sola vez aunque se reentrene varias veces.
  const cacheMemoria = new Map();
  const claveArchivo = (a) => `${a.name}|${a.size}|${a.lastModified}`;

  // 4 variantes por imagen (original, espejo, más clara, espejo más oscura) para tener más ejemplos.
  function variantes(img) {
    return [
      extraerCaracteristicas(leerPixeles(img, false, 1)),
      extraerCaracteristicas(leerPixeles(img, true, 1)),
      extraerCaracteristicas(leerPixeles(img, false, 1.15)),
      extraerCaracteristicas(leerPixeles(img, true, 0.85))
    ];
  }

  async function variantesDeArchivo(archivo) {
    const clave = claveArchivo(archivo);
    if (cacheMemoria.has(clave)) return cacheMemoria.get(clave);
    const img = await cargarImagen(archivo);
    const v = variantes(img);
    cacheMemoria.set(clave, v);
    return v;
  }

  const gauss = () => {
    let u = 0, v = 0;
    while (u === 0) u = Math.random();
    while (v === 0) v = Math.random();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  };
  const pausa = () => new Promise((r) => setTimeout(r, 0));

  function pasoAdelante(m, z) {
    const { d, H, W1, b1, W2, b2 } = m;
    const h = new Float64Array(H);
    for (let j = 0; j < H; j++) h[j] = b1[j];
    for (let i = 0; i < d; i++) {
      const zi = z[i];
      if (zi === 0) continue;
      const base = i * H;
      for (let j = 0; j < H; j++) h[j] += zi * W1[base + j];
    }
    let o0 = b2[0], o1 = b2[1];
    for (let j = 0; j < H; j++) {
      if (h[j] < 0) h[j] = 0;
      o0 += h[j] * W2[j * 2]; o1 += h[j] * W2[j * 2 + 1];
    }
    const mx = Math.max(o0, o1);
    const e0 = Math.exp(o0 - mx), e1 = Math.exp(o1 - mx);
    return { h, p: [e0 / (e0 + e1), e1 / (e0 + e1)] };
  }

  const estandarizar = (m, x) => Float64Array.from(x, (v, j) => (v - m.mu[j]) / m.sigma[j]);

  async function entrenarRed(X, Y, alEpoca) {
    const n = X.length, d = X[0].length, H = 32;
    const mu = new Float64Array(d), sigma = new Float64Array(d);
    for (let j = 0; j < d; j++) {
      let s = 0;
      for (let i = 0; i < n; i++) s += X[i][j];
      mu[j] = s / n;
      let v = 0;
      for (let i = 0; i < n; i++) v += (X[i][j] - mu[j]) ** 2;
      sigma[j] = Math.sqrt(v / n) + 1e-6;
    }
    const m = {
      d, H, mu, sigma,
      W1: Float64Array.from({ length: d * H }, () => gauss() * Math.sqrt(2 / d)),
      b1: new Float64Array(H),
      W2: Float64Array.from({ length: H * 2 }, () => gauss() * Math.sqrt(2 / H)),
      b2: new Float64Array(2)
    };
    const Z = X.map((x) => estandarizar(m, x));
    const claves = ["W1", "b1", "W2", "b2"];
    const M = {}, V = {}, G = {};
    claves.forEach((k) => { M[k] = new Float64Array(m[k].length); V[k] = new Float64Array(m[k].length); G[k] = new Float64Array(m[k].length); });
    const LR = 0.003, B1 = 0.9, B2 = 0.999, L2 = 1e-3, LOTE = 8;
    let t = 0;
    const orden = Array.from({ length: n }, (_, i) => i);

    for (let ep = 0; ep < EPOCAS; ep++) {
      for (let i = n - 1; i > 0; i--) { const k = Math.floor(Math.random() * (i + 1)); [orden[i], orden[k]] = [orden[k], orden[i]]; }
      let perdida = 0, aciertos = 0;
      for (let ini = 0; ini < n; ini += LOTE) {
        const lote = orden.slice(ini, ini + LOTE);
        claves.forEach((k) => G[k].fill(0));
        for (const s of lote) {
          const z = Z[s], y = Y[s];
          const { h, p } = pasoAdelante(m, z);
          perdida += -Math.log(Math.max(p[y], 1e-9));
          if ((p[0] >= p[1] ? 0 : 1) === y) aciertos++;
          const dz0 = p[0] - (y === 0 ? 1 : 0), dz1 = p[1] - (y === 1 ? 1 : 0);
          G.b2[0] += dz0; G.b2[1] += dz1;
          for (let j = 0; j < H; j++) {
            G.W2[j * 2] += h[j] * dz0; G.W2[j * 2 + 1] += h[j] * dz1;
            const dh = h[j] > 0 ? m.W2[j * 2] * dz0 + m.W2[j * 2 + 1] * dz1 : 0;
            if (dh === 0) continue;
            G.b1[j] += dh;
            for (let i = 0; i < d; i++) G.W1[i * H + j] += z[i] * dh;
          }
        }
        t++;
        const c1 = 1 - Math.pow(B1, t), c2 = 1 - Math.pow(B2, t);
        for (const k of claves) {
          const P = m[k], g = G[k], mk = M[k], vk = V[k];
          const reg = k[0] === "W" ? L2 : 0;
          for (let i = 0; i < P.length; i++) {
            const gr = g[i] / lote.length + reg * P[i];
            mk[i] = B1 * mk[i] + (1 - B1) * gr;
            vk[i] = B2 * vk[i] + (1 - B2) * gr * gr;
            P[i] -= LR * (mk[i] / c1) / (Math.sqrt(vk[i] / c2) + 1e-8);
          }
        }
      }
      await alEpoca(ep, perdida / n, aciertos / n);
    }
    return m;
  }

  function predecir(m, x) { return pasoAdelante(m, estandarizar(m, x)).p; }

  /* ============ Caché del modelo (Cache API) ============ */
  const CACHE_MODELO = "cbtis260-modelo";
  const CLAVE_MODELO = "./modelo-guardado.json";

  async function guardarModelo() {
    try {
      if (!("caches" in window) || !clasificador) return;
      const m = clasificador;
      const datos = {
        d: m.d, H: m.H, nombres: [categorias.A.nombre.value.trim(), categorias.B.nombre.value.trim()],
        mu: Array.from(m.mu), sigma: Array.from(m.sigma), W1: Array.from(m.W1), b1: Array.from(m.b1), W2: Array.from(m.W2), b2: Array.from(m.b2)
      };
      const c = await caches.open(CACHE_MODELO);
      await c.put(CLAVE_MODELO, new Response(JSON.stringify(datos), { headers: { "Content-Type": "application/json" } }));
    } catch (e) { console.warn("No se pudo guardar el modelo en caché:", e); }
  }

  async function restaurarModelo() {
    try {
      if (!("caches" in window)) return;
      const c = await caches.open(CACHE_MODELO);
      const resp = await c.match(CLAVE_MODELO);
      if (!resp) return;
      const o = await resp.json();
      clasificador = {
        d: o.d, H: o.H, mu: Float64Array.from(o.mu), sigma: Float64Array.from(o.sigma),
        W1: Float64Array.from(o.W1), b1: Float64Array.from(o.b1), W2: Float64Array.from(o.W2), b2: Float64Array.from(o.b2)
      };
      categorias.A.nombre.value = o.nombres[0] || categorias.A.nombre.value;
      categorias.B.nombre.value = o.nombres[1] || categorias.B.nombre.value;
      $("abrirCamara").disabled = false;
      $("analizar").disabled = !fotoSeleccionada;
      estado("Modelo restaurado desde la caché del navegador. Puedes analizar una imagen o volver a entrenar.");
    } catch (e) { console.warn("No se pudo restaurar el modelo:", e); }
  }

  /* ============ Interfaz (igual que antes) ============ */
  function avisar(mensaje) {
    const n = $("notificacion");
    n.textContent = mensaje;
    n.classList.add("visible");
    window.clearTimeout(avisar.timer);
    avisar.timer = window.setTimeout(() => n.classList.remove("visible"), 3500);
  }

  function estado(mensaje) { $("estadoEntrenamiento").textContent = mensaje; }

  // Navegación entre secciones sin recargar la página.
  document.querySelectorAll("[data-seccion], [data-ir]").forEach((boton) => {
    boton.addEventListener("click", () => {
      const destino = boton.dataset.seccion || boton.dataset.ir;
      document.querySelectorAll(".seccion").forEach((seccion) => {
        const activa = seccion.id === destino;
        seccion.hidden = !activa;
        seccion.classList.toggle("visible", activa);
      });
      document.querySelectorAll("[data-seccion]").forEach((b) => b.classList.toggle("activo", b.dataset.seccion === destino));
      if (destino === "solucion") $("solucion").scrollIntoView({ behavior: "smooth", block: "start" });
      else $("problematica").scrollIntoView({ behavior: "smooth", block: "start" });
    });
  });

  function renderizarCategoria(clave) {
    const cat = categorias[clave];
    cat.vista.replaceChildren();
    cat.archivos.forEach((archivo, indice) => {
      const url = URL.createObjectURL(archivo);
      const caja = document.createElement("div");
      caja.className = "miniatura";
      const img = document.createElement("img");
      img.src = url;
      img.alt = `Imagen ${indice + 1} de categoría ${clave}`;
      const quitar = document.createElement("button");
      quitar.type = "button";
      quitar.textContent = "×";
      quitar.setAttribute("aria-label", `Eliminar imagen ${indice + 1}`);
      quitar.addEventListener("click", () => {
        URL.revokeObjectURL(url);
        cat.archivos.splice(indice, 1);
        renderizarCategoria(clave);
        invalidarEntrenamiento();
      });
      caja.append(img, quitar);
      cat.vista.append(caja);
    });
    cat.contador.textContent = `${cat.archivos.length} de ${MAX_IMAGENES} imágenes · mínimo ${MIN_IMAGENES}`;
  }

  function invalidarEntrenamiento() {
    $("analizar").disabled = true;
    $("abrirCamara").disabled = true;
    $("resultado").hidden = true;
    clasificador = null;
    estado("Las imágenes cambiaron. Vuelve a entrenar el modelo.");
  }

  Object.entries(categorias).forEach(([clave, cat]) => {
    cat.input.addEventListener("change", () => {
      const seleccionadas = Array.from(cat.input.files || []);
      const disponibles = MAX_IMAGENES - cat.archivos.length;
      const imagenes = seleccionadas.filter((f) => f.type.startsWith("image/"));
      if (imagenes.length !== seleccionadas.length) avisar("Se omitieron archivos que no son imágenes.");
      if (imagenes.length > disponibles) avisar(`Solo puedes agregar ${disponibles} imagen(es) más a esta categoría.`);
      cat.archivos.push(...imagenes.slice(0, disponibles));
      if (cat.archivos.length > MAX_IMAGENES) cat.archivos = cat.archivos.slice(0, MAX_IMAGENES);
      renderizarCategoria(clave);
      invalidarEntrenamiento();
      cat.input.value = "";
    });
    cat.limpiar.addEventListener("click", () => {
      cat.archivos = [];
      renderizarCategoria(clave);
      invalidarEntrenamiento();
    });
    cat.nombre.addEventListener("input", invalidarEntrenamiento);
  });

  function cargarImagen(archivo) {
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(archivo);
      const img = new Image();
      img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
      img.onerror = () => { URL.revokeObjectURL(url); reject(new Error(`No se pudo abrir la imagen ${archivo.name || ""}.`)); };
      img.src = url;
    });
  }

  function actualizarVistaNueva(imgSrc) {
    $("vistaNueva").src = imgSrc;
    $("vistaNueva").hidden = false;
    $("sinFoto").hidden = true;
    $("analizar").disabled = !clasificador;
    $("quitarNueva").disabled = false;
    $("resultado").hidden = true;
  }

  $("fotoNueva").addEventListener("change", async () => {
    const archivo = $("fotoNueva").files[0];
    if (!archivo) return;
    if (!archivo.type.startsWith("image/")) { avisar("Selecciona un archivo de imagen válido."); return; }
    try {
      fotoSeleccionada = await cargarImagen(archivo);
      if (urlFoto) URL.revokeObjectURL(urlFoto);
      urlFoto = URL.createObjectURL(archivo);
      actualizarVistaNueva(urlFoto);
    } catch (e) { avisar(e.message); }
  });

  $("quitarNueva").addEventListener("click", () => {
    fotoSeleccionada = null;
    if (urlFoto) URL.revokeObjectURL(urlFoto);
    urlFoto = null;
    $("vistaNueva").removeAttribute("src");
    $("vistaNueva").hidden = true;
    $("sinFoto").hidden = false;
    $("fotoNueva").value = "";
    $("analizar").disabled = true;
    $("quitarNueva").disabled = true;
    $("resultado").hidden = true;
  });

  $("entrenar").addEventListener("click", async () => {
    if (entrenamientoEnCurso) return;
    for (const [clave, cat] of Object.entries(categorias)) {
      if (cat.archivos.length < MIN_IMAGENES || cat.archivos.length > MAX_IMAGENES) {
        avisar(`La categoría ${clave} necesita entre ${MIN_IMAGENES} y ${MAX_IMAGENES} imágenes válidas.`);
        return;
      }
      if (!cat.nombre.value.trim()) { avisar(`Escribe un nombre para la categoría ${clave}.`); cat.nombre.focus(); return; }
    }
    entrenamientoEnCurso = true;
    $("entrenar").disabled = true;
    $("contenedorProgreso").hidden = false;
    $("barraProgreso").style.width = "0%";
    try {
      const xs = [];
      const ys = [];
      const total = categorias.A.archivos.length + categorias.B.archivos.length;
      let procesadas = 0;
      for (const [clave, cat] of Object.entries(categorias)) {
        const clase = clave === "A" ? 0 : 1;
        for (const archivo of cat.archivos) {
          estado(`Analizando características de imagen ${procesadas + 1} de ${total}…`);
          const vs = await variantesDeArchivo(archivo);
          vs.forEach((v) => { xs.push(v); ys.push(clase); });
          procesadas++;
          $("barraProgreso").style.width = `${Math.round((procesadas / total) * 60)}%`;
          $("textoProgreso").textContent = `Preparando datos: ${procesadas}/${total}`;
          await pausa();
        }
      }

      estado("Entrenando la red neuronal con tus imágenes…");
      clasificador = null;
      const modelo = await entrenarRed(xs, ys, async (ep, perdida, precision) => {
        $("barraProgreso").style.width = `${60 + Math.round(((ep + 1) / EPOCAS) * 40)}%`;
        $("textoProgreso").textContent = `Época ${ep + 1}/${EPOCAS} · pérdida: ${perdida.toFixed(4)} · precisión: ${Math.round(precision * 100)}%`;
        await pausa();
      });
      clasificador = modelo;
      await guardarModelo();
      $("barraProgreso").style.width = "100%";
      $("textoProgreso").textContent = "Entrenamiento completado.";
      estado("Modelo entrenado. Ya puedes analizar una imagen nueva.");
      $("analizar").disabled = !fotoSeleccionada;
      $("abrirCamara").disabled = false;
      avisar("¡Entrenamiento terminado correctamente!");
    } catch (error) {
      console.error(error);
      estado(`No se pudo entrenar: ${error.message}`);
      avisar("Ocurrió un error durante el entrenamiento. Revisa las imágenes e inténtalo de nuevo.");
    } finally {
      entrenamientoEnCurso = false;
      $("entrenar").disabled = false;
    }
  });

  $("analizar").addEventListener("click", async () => {
    if (!clasificador || !fotoSeleccionada) return;
    $("analizar").disabled = true;
    try {
      estado("Analizando imagen…");
      await pausa();
      const caracteristicas = extraerCaracteristicas(leerPixeles(fotoSeleccionada, false, 1));
      const puntuaciones = predecir(clasificador, caracteristicas);
      const indice = puntuaciones[0] >= puntuaciones[1] ? 0 : 1;
      const confianza = puntuaciones[indice];
      const nombres = [categorias.A.nombre.value.trim(), categorias.B.nombre.value.trim()];
      const etiqueta = confianza >= UMBRAL_CONFIANZA ? nombres[indice] : "Foto ni de usuario ni de no usuario";
      $("etiquetaResultado").textContent = etiqueta;
      $("detalleResultado").textContent = confianza >= UMBRAL_CONFIANZA
        ? `La categoría con mayor puntuación fue “${nombres[indice]}”.`
        : "Ninguna categoría alcanzó el umbral configurado. Esta etiqueta es provisional; el modelo solo aprendió dos categorías.";
      $("barraConfianza").style.width = `${Math.round(confianza * 100)}%`;
      $("textoConfianza").textContent = `Puntuación de la categoría más probable: ${(confianza * 100).toFixed(1)}% · Umbral: ${Math.round(UMBRAL_CONFIANZA * 100)}%`;
      $("resultado").hidden = false;
      estado("Análisis terminado.");
    } catch (error) {
      console.error(error);
      avisar(`No se pudo analizar la imagen: ${error.message}`);
    } finally { $("analizar").disabled = !clasificador || !fotoSeleccionada; }
  });

  $("abrirCamara").addEventListener("click", async () => {
    try {
      if (!navigator.mediaDevices?.getUserMedia) throw new Error("Tu navegador no permite abrir la cámara aquí. Usa HTTPS o localhost.");
      camara = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: "environment" } }, audio: false });
      $("videoCamara").srcObject = camara;
      $("videoCamara").hidden = false;
      $("capturar").hidden = false;
      $("detenerCamara").hidden = false;
      $("abrirCamara").disabled = true;
    } catch (error) {
      avisar(error.name === "NotAllowedError" ? "Se rechazó el permiso de cámara. Puedes habilitarlo en los permisos del sitio." : `No se pudo abrir la cámara: ${error.message}`);
    }
  });

  function detenerCamara() {
    if (camara) camara.getTracks().forEach((pista) => pista.stop());
    camara = null;
    $("videoCamara").srcObject = null;
    $("videoCamara").hidden = true;
    $("capturar").hidden = true;
    $("detenerCamara").hidden = true;
    $("abrirCamara").disabled = !clasificador;
  }
  $("detenerCamara").addEventListener("click", detenerCamara);

  $("capturar").addEventListener("click", () => {
    const video = $("videoCamara");
    if (!video.videoWidth) { avisar("Espera a que la cámara muestre la imagen."); return; }
    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext("2d").drawImage(video, 0, 0);
    canvas.toBlob(async (blob) => {
      if (!blob) { avisar("No se pudo capturar la fotografía."); return; }
      fotoSeleccionada = await cargarImagen(blob);
      if (urlFoto) URL.revokeObjectURL(urlFoto);
      urlFoto = URL.createObjectURL(blob);
      actualizarVistaNueva(urlFoto);
      detenerCamara();
    }, "image/jpeg", 0.9);
  });

  restaurarModelo();

  // Registro del service worker solo en localhost o HTTPS.
  if ("serviceWorker" in navigator && (location.protocol === "https:" || location.hostname === "localhost" || location.hostname === "127.0.0.1")) {
    window.addEventListener("load", () => navigator.serviceWorker.register("./service-worker.js").catch((e) => console.warn("No se pudo registrar el service worker:", e)));
  }
})();
